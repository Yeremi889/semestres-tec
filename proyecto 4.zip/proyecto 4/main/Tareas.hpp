/*****Datos administrativos************************
 * Nombre del archivo: Tareas.hpp
 * Tipo de archivo: Encabezado
 * Proyecto: Gestión de Tareas y Proyectos
 * Autor: Deislher Sánchez, Yeremi Calvo
 * Empresa: Tecnológico de Costa Rica
 *****Descripción**********************************
 * Clase que representa una tarea en el contexto de 
 * un grafo. Cada tarea tiene un nombre, una duración 
 * y una lista de recursos asociados.
 *****Versión**************************************
 * 1.0 | [17-11-2024 11:50] | [Deislher Sánchez]
 * 2.0 | [24-11-2024 5:45] | [Yeremi Calvo]
 **************************************************/

#ifndef TAREAS_HPP
#define TAREAS_HPP

#include "String.hpp"
#include <iostream>

/*****Nombre***************************************
 * Tarea
 *****Descripción**********************************
 * Clase que encapsula los atributos y métodos 
 * asociados a una tarea en un proyecto.
 *****Atributos************************************
 * - aNombre: Nombre de la tarea.
 * - aDuracion: Duración estimada de la tarea en horas.
 * - apRecursos: Lista de recursos asociados a la tarea.
 *****Métodos**************************************
 * - Constructor y destructor.
 * - Métodos para obtener y modificar los atributos.
 * - Métodos para gestionar los recursos.
 **************************************************/
class Tarea {
private:
    String aNombre;               
    int aDuracion;            
    String** apRecursos;           

public:
    /*****Nombre***************************************
     * Tarea (constructor)
     *****Descripción**********************************
     * Inicializa una tarea con un nombre y una duración.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - nombre: Nombre de la tarea.
     * - duracion: Duración estimada de la tarea en horas.
     **************************************************/
    Tarea(String nombre, int duracion)
        : aNombre(nombre), aDuracion(duracion), apRecursos(nullptr) {}

    /*****Nombre***************************************
     * ~Tarea (destructor)
     *****Descripción**********************************
     * Libera los recursos asociados a la tarea, incluyendo
     * la lista dinámica de recursos.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    ~Tarea() {
        int i = 0;
        while (apRecursos && apRecursos[i] != nullptr) {
            delete apRecursos[i];
            i++;
        }
        delete[] apRecursos;
    }

    /*****Nombre***************************************
     * getNombre
     *****Descripción**********************************
     * Devuelve el nombre de la tarea.
     *****Retorno**************************************
     * Nombre de la tarea.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    String getNombre() {
        return aNombre;
    }

    /*****Nombre***************************************
     * getDuracion
     *****Descripción**********************************
     * Devuelve la duración de la tarea.
     *****Retorno**************************************
     * Duración de la tarea en horas.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    int getDuracion() {
        return aDuracion;
    }

    /*****Nombre***************************************
     * getRecursos
     *****Descripción**********************************
     * Devuelve la lista de recursos asociados a la tarea.
     *****Retorno**************************************
     * Puntero al arreglo dinámico de recursos.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    String** getRecursos() {
        return apRecursos;
    }

    /*****Nombre***************************************
     * getCantidadRecursos
     *****Descripción**********************************
     * Devuelve el número de recursos asociados a la tarea.
     *****Retorno**************************************
     * Número de recursos.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    int getCantidadRecursos() const {
        int cantidad = 0;
        if (apRecursos != nullptr) {
            while (apRecursos[cantidad] != nullptr) {
                cantidad++;
            }
        }
        return cantidad;
    }

    /*****Nombre***************************************
     * setNombre
     *****Descripción**********************************
     * Establece un nuevo nombre para la tarea.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - nuevoNombre: Nuevo nombre de la tarea.
     **************************************************/
    void setNombre(String nuevoNombre) {
        aNombre = nuevoNombre;
    }

    /*****Nombre***************************************
     * setDuracion
     *****Descripción**********************************
     * Establece una nueva duración para la tarea.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - nuevaDuracion: Nueva duración de la tarea en horas.
     **************************************************/
    void setDuracion(int nuevaDuracion) {
        aDuracion = nuevaDuracion;
    }

    /*****Nombre***************************************
     * setRecursos
     *****Descripción**********************************
     * Establece una nueva lista de recursos para la tarea.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - nuevosRecursos: Arreglo dinámico con los nuevos recursos.
     **************************************************/
    void setRecursos(String** nuevosRecursos) {
        if (apRecursos != nullptr) {
            int i = 0;
            while (apRecursos[i] != nullptr) {
                delete apRecursos[i];
                i++;
            }
            delete[] apRecursos;
        }
        int cantidad = 0;
        while (nuevosRecursos[cantidad] != nullptr) {
            cantidad++;
        }
        apRecursos = new String*[cantidad + 1];
        for (int i = 0; i < cantidad; i++) {
            apRecursos[i] = new String(*nuevosRecursos[i]); 
        }
        apRecursos[cantidad] = nullptr; 
    }

    /*****Nombre***************************************
     * agregarRecurso
     *****Descripción**********************************
     * Agrega un nuevo recurso a la lista de recursos de la tarea.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - nuevoRecurso: Puntero al recurso a agregar.
     **************************************************/
    void agregarRecurso(String* nuevoRecurso) {
        int cantidad = getCantidadRecursos(); 
        String** nuevaLista = new String*[cantidad + 2];
        for (int i = 0; i < cantidad; i++) {
            nuevaLista[i] = apRecursos[i];
        }
        nuevaLista[cantidad] = nuevoRecurso;
        nuevaLista[cantidad + 1] = nullptr;
        delete[] apRecursos;
        apRecursos = nuevaLista;
    }
};

#endif // TAREAS_HPP
