/*****Datos administrativos************************
 * Nombre del archivo: GrafoDeTareas.hpp
 * Tipo de archivo: Encabezado
 * Proyecto: Gestión de Tareas y Proyectos
 * Autor: Deislher Sánchez, Yeremi Calvo
 * Empresa: Tecnológico de Costa Rica
 *****Descripción**********************************
 * Clase que representa un grafo de tareas, donde 
 * cada nodo corresponde a una tarea y las aristas 
 * representan dependencias entre tareas.
 *****Versión**************************************
 * 1.0 | [17-11-2024 11:50] | [Deislher Sánchez]
 * 2.0 | [24-11-2024 5:45] | [Yeremi Calvo]
 **************************************************/

#ifndef GRAFODETAREAS_HPP
#define GRAFODETAREAS_HPP

#include "Nodo.hpp"
#include <iostream>

/*****Nombre***************************************
 * GrafoDeTareas
 *****Descripción**********************************
 * Clase que encapsula un conjunto de tareas y sus 
 * relaciones en forma de grafo. Gestiona nodos y 
 * dependencias entre ellos.
 *****Atributos************************************
 * - apNodos: Arreglo dinámico de nodos.
 * - aCantidadNodos: Número de nodos actuales en el grafo.
 * - aCapacidad: Capacidad máxima actual del arreglo.
 *****Métodos**************************************
 * - Constructor y destructor.
 * - Métodos para agregar, eliminar y mostrar tareas y dependencias.
 **************************************************/
class GrafoDeTareas {
private:
    Nodo** apNodos;       
    int aCantidadNodos;   
    int aCapacidad;       

    /*****Nombre***************************************
     * redimensionar
     *****Descripción**********************************
     * Incrementa la capacidad del arreglo dinámico de nodos
     * cuando se alcanza su capacidad máxima.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    void redimensionar() {
        int nuevaCapacidad = aCapacidad * 2;
        Nodo** nuevoArreglo = new Nodo*[nuevaCapacidad];

        for (int i = 0; i < aCantidadNodos; i++) {
            nuevoArreglo[i] = apNodos[i];
        }

        delete[] apNodos;
        apNodos = nuevoArreglo;
        aCapacidad = nuevaCapacidad;
    }

public:
    /*****Nombre***************************************
     * GrafoDeTareas (constructor)
     *****Descripción**********************************
     * Inicializa un grafo con capacidad inicial definida.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - capacidadInicial: Tamaño inicial del arreglo dinámico.
     **************************************************/
    GrafoDeTareas(int capacidadInicial = 10)
        : apNodos(new Nodo*[capacidadInicial]), aCantidadNodos(0), aCapacidad(capacidadInicial) {}

    /*****Nombre***************************************
     * ~GrafoDeTareas (destructor)
     *****Descripción**********************************
     * Libera los recursos asociados al grafo, incluyendo 
     * los nodos y dependencias almacenadas.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    ~GrafoDeTareas() {
        for (int i = 0; i < aCantidadNodos; i++) {
            delete apNodos[i];
        }
        delete[] apNodos;
    }

    /*****Nombre***************************************
     * agregarTarea
     *****Descripción**********************************
     * Agrega una nueva tarea al grafo, creando un nodo 
     * correspondiente.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - pTarea: Puntero a la tarea a agregar.
     **************************************************/
    void agregarTarea(Tarea* pTarea) {
        if (aCantidadNodos == aCapacidad) {
            redimensionar();
        }
        apNodos[aCantidadNodos++] = new Nodo(pTarea);
    }

    /*****Nombre***************************************
     * agregarDependencia
     *****Descripción**********************************
     * Agrega una dependencia desde un nodo origen hacia 
     * un nodo destino con un peso específico.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - idOrigen: ID del nodo origen.
     * - idDestino: ID del nodo destino.
     * - peso: Peso de la dependencia.
     **************************************************/
    void agregarDependencia(int idOrigen, int idDestino, int peso) {
        apNodos[idOrigen]->agregarDependencia(idDestino, peso);
    }

    /*****Nombre***************************************
     * eliminarDependencia
     *****Descripción**********************************
     * Elimina una dependencia desde un nodo origen hacia 
     * un nodo destino.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - idOrigen: ID del nodo origen.
     * - idDestino: ID del nodo destino.
     **************************************************/
    void eliminarDependencia(int idOrigen, int idDestino) {
        apNodos[idOrigen]->eliminarDependencia(idDestino);
    }

    /*****Nombre***************************************
     * obtenerNodo
     *****Descripción**********************************
     * Devuelve el nodo asociado a un ID específico.
     *****Retorno**************************************
     * Puntero al nodo correspondiente.
     *****Entradas*************************************
     * - id: ID del nodo a obtener.
     **************************************************/
    Nodo* obtenerNodo(int id) {
        return apNodos[id];
    }

    /*****Nombre***************************************
     * eliminarNodo
     *****Descripción**********************************
     * Elimina un nodo del grafo y ajusta las dependencias 
     * de los demás nodos para reflejar la eliminación.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - id: ID del nodo a eliminar.
     **************************************************/
    void eliminarNodo(int id) {
        delete apNodos[id];
        for (int i = id; i < aCantidadNodos - 1; i++) {
            apNodos[i] = apNodos[i + 1];
        }
        aCantidadNodos--;
        for (int i = 0; i < aCantidadNodos; i++) {
            Dependencia** dependencias = apNodos[i]->getDependencias();
            int cantidadDependencias = apNodos[i]->getCantidadDependencias();
            Dependencia** nuevasDependencias = new Dependencia*[cantidadDependencias];
            int nuevasCantidad = 0;

            for (int j = 0; j < cantidadDependencias; j++) {
                if (dependencias[j]->getIdDestino() != id) {
                    nuevasDependencias[nuevasCantidad++] = dependencias[j];
                } else {
                    delete dependencias[j];
                }
            }
            delete[] dependencias;
            apNodos[i]->setDependencias(nuevasDependencias, nuevasCantidad);
        }
    }

    /*****Nombre***************************************
     * mostrarGrafo
     *****Descripción**********************************
     * Muestra los nodos del grafo junto con sus tareas 
     * y dependencias en consola.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    void mostrarGrafo() {
        if (aCantidadNodos == 0) {
            std::cout << "No hay nodos en el grafo.\n";
            return;
        }
        for (int i = 0; i < aCantidadNodos; i++) {
            Nodo* nodo = apNodos[i];
            std::cout << "Tarea ID: " << i << " - Nombre: "
                      << nodo->getTarea()->getNombre().mostrarCadena() << "\n";

            for (int j = 0; j < nodo->getCantidadDependencias(); j++) {
                Dependencia* dep = nodo->getDependencias()[j];
                std::cout << "  -> Depende de ID: " << dep->getIdDestino()
                          << " (Peso: " << dep->getPeso() << ")\n";
            }
        }
    }
};

#endif // GRAFODETAREAS_HPP
