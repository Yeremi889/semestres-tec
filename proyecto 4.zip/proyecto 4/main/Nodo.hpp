/*****Datos administrativos************************
 * Nombre del archivo: Nodo.hpp
 * Tipo de archivo: Encabezado
 * Proyecto: Gestión de Tareas y Proyectos
 * Autor: Deislher Sánchez, Yeremi Calvo
 * Empresa: Tecnológico de Costa Rica
 *****Descripción**********************************
 * Clase que representa un nodo dentro de un grafo 
 * de tareas. Cada nodo corresponde a una tarea y 
 * puede contener dependencias hacia otros nodos.
 *****Versión**************************************
 * 1.0 | [17-11-2024 11:50] | [Deislher Sánchez]
 * 2.0 | [24-11-2024 5:45] | [Yeremi Calvo]
 **************************************************/

#ifndef NODO_HPP
#define NODO_HPP

#include "Tareas.hpp"
#include "Dependencia.hpp"

/*****Nombre***************************************
 * Nodo
 *****Descripción**********************************
 * Clase que encapsula una tarea y sus dependencias 
 * en un contexto de grafo. Permite gestionar las 
 * relaciones entre tareas.
 *****Atributos************************************
 * - pTarea: Puntero a la tarea asociada al nodo.
 * - apDependencias: Arreglo dinámico de dependencias.
 * - aCantidadDependencias: Número de dependencias.
 *****Métodos**************************************
 * - Constructor y destructor.
 * - Métodos para agregar, eliminar y obtener dependencias.
 * - Método para verificar si existe una dependencia.
 **************************************************/
class Nodo {
private:
    Tarea* pTarea;                   // Tarea asociada al nodo
    Dependencia** apDependencias;    // Arreglo dinámico de dependencias
    int aCantidadDependencias;       // Número de dependencias del nodo

public:

    /*****Nombre***************************************
     * Nodo (constructor)
     *****Descripción**********************************
     * Inicializa un nodo con una tarea específica.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - pNuevaTarea: Puntero a la tarea asociada al nodo.
     **************************************************/
    Nodo(Tarea* pNuevaTarea)
        : pTarea(pNuevaTarea), apDependencias(nullptr), aCantidadDependencias(0) {}

    /*****Nombre***************************************
     * ~Nodo (destructor)
     *****Descripción**********************************
     * Libera los recursos asociados al nodo, incluyendo 
     * su tarea y dependencias.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    ~Nodo() {
        delete pTarea;
        if (apDependencias != nullptr) {
            for (int i = 0; i < aCantidadDependencias; i++) {
                delete apDependencias[i];
            }
            delete[] apDependencias;
        }
    }

    /*****Nombre***************************************
     * getTarea
     *****Descripción**********************************
     * Devuelve la tarea asociada al nodo.
     *****Retorno**************************************
     * Puntero a la tarea del nodo.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    Tarea* getTarea() {
        return pTarea;
    }

    /*****Nombre***************************************
     * getCantidadDependencias
     *****Descripción**********************************
     * Devuelve el número de dependencias del nodo.
     *****Retorno**************************************
     * Número de dependencias.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    int getCantidadDependencias() {
        return aCantidadDependencias;
    }

    /*****Nombre***************************************
     * getDependencias
     *****Descripción**********************************
     * Devuelve el arreglo de dependencias del nodo.
     *****Retorno**************************************
     * Arreglo dinámico de dependencias.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    Dependencia** getDependencias() {
        return apDependencias;
    }

    /*****Nombre***************************************
     * agregarDependencia
     *****Descripción**********************************
     * Agrega una dependencia hacia otro nodo en el grafo.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - idDestino: ID del nodo destino.
     * - peso: Peso de la dependencia.
     **************************************************/
    void agregarDependencia(int idDestino, int peso) {
        Dependencia** nuevasDependencias = new Dependencia*[aCantidadDependencias + 1];
        
        for (int i = 0; i < aCantidadDependencias; i++) {
            nuevasDependencias[i] = apDependencias[i];
        }

        nuevasDependencias[aCantidadDependencias] = new Dependencia(-1, idDestino, peso);

        delete[] apDependencias;
        apDependencias = nuevasDependencias;
        aCantidadDependencias++;
    }

    /*****Nombre***************************************
     * existeDependencia
     *****Descripción**********************************
     * Verifica si existe una dependencia hacia un nodo destino.
     *****Retorno**************************************
     * Verdadero si la dependencia existe, falso en caso contrario.
     *****Entradas*************************************
     * - idDestino: ID del nodo destino.
     **************************************************/
    bool existeDependencia(int idDestino) {
        for (int i = 0; i < aCantidadDependencias; i++) {
            if (apDependencias[i]->getIdDestino() == idDestino) {
                return true;
            }
        }
        return false;
    }

    /*****Nombre***************************************
     * eliminarDependencia
     *****Descripción**********************************
     * Elimina la dependencia hacia un nodo destino específico.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - idDestino: ID del nodo destino.
     **************************************************/
    void eliminarDependencia(int idDestino) {
        int nuevasCantidad = 0;
        Dependencia** nuevasDependencias = new Dependencia*[aCantidadDependencias - 1];
        
        for (int i = 0; i < aCantidadDependencias; i++) {
            if (apDependencias[i]->getIdDestino() != idDestino) {
                nuevasDependencias[nuevasCantidad++] = apDependencias[i];
            } else {
                delete apDependencias[i];  
            }
        }

        if (nuevasCantidad == aCantidadDependencias) {
            delete[] nuevasDependencias;
            return;
        }

        delete[] apDependencias;
        apDependencias = nuevasDependencias;
        aCantidadDependencias = nuevasCantidad;
    }

    /*****Nombre***************************************
     * setDependencias
     *****Descripción**********************************
     * Actualiza el arreglo de dependencias del nodo.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - apNuevasDependencias: Nuevo arreglo de dependencias.
     * - nuevaCantidad: Número de dependencias en el nuevo arreglo.
     **************************************************/
    void setDependencias(Dependencia** apNuevasDependencias, int nuevaCantidad) {
        if (apDependencias != nullptr) {
            for (int i = 0; i < aCantidadDependencias; i++) {
                delete apDependencias[i];
            }
            delete[] apDependencias;
        }
        apDependencias = apNuevasDependencias;
        aCantidadDependencias = nuevaCantidad;
    }
};

#endif // NODO_HPP
