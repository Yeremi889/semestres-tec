/*****Datos administrativos************************
 * Nombre del archivo: Dependencia.hpp
 * Tipo de archivo: Encabezado
 * Proyecto: Gestión de Tareas y Proyectos
 * Autor: Deislher Sánchez, Yeremi Calvo
 * Empresa: Tecnológico de Costa Rica
 *****Descripción**********************************
 * Clase que representa una dependencia entre dos nodos
 * en un grafo de tareas. Contiene información sobre 
 * los nodos origen y destino, así como el peso de la 
 * dependencia.
 *****Versión**************************************
 * 1.0 | [24-11-2024 5:45] | [Yeremi Calvo]
 **************************************************/

#ifndef DEPENDENCIA_HPP
#define DEPENDENCIA_HPP

/*****Nombre***************************************
 * Dependencia
 *****Descripción**********************************
 * Clase que encapsula las características de una 
 * dependencia entre nodos, incluyendo su peso y 
 * los identificadores de los nodos involucrados.
 *****Atributos************************************
 * - aIdOrigen: ID del nodo origen de la dependencia.
 * - aIdDestino: ID del nodo destino de la dependencia.
 * - aPeso: Peso de la dependencia.
 *****Métodos**************************************
 * - Constructor para inicializar los atributos.
 * - Métodos para obtener y modificar los atributos.
 **************************************************/
class Dependencia {
private:
    int aIdOrigen;   
    int aIdDestino;  
    int aPeso;       

public:
    /*****Nombre***************************************
     * Dependencia (constructor)
     *****Descripción**********************************
     * Inicializa una dependencia con el nodo origen, 
     * el nodo destino y un peso.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - idOrigen: ID del nodo origen.
     * - idDestino: ID del nodo destino.
     * - peso: Peso de la dependencia.
     **************************************************/
    Dependencia(int idOrigen, int idDestino, int peso) {
        aIdOrigen = idOrigen;
        aIdDestino = idDestino;
        aPeso = peso;
    }

    /*****Nombre***************************************
     * setIdOrigen
     *****Descripción**********************************
     * Establece el ID del nodo origen de la dependencia.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - idOrigen: Nuevo ID del nodo origen.
     **************************************************/
    void setIdOrigen(int idOrigen) {
        aIdOrigen = idOrigen;
    }

    /*****Nombre***************************************
     * setIdDestino
     *****Descripción**********************************
     * Establece el ID del nodo destino de la dependencia.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - idDestino: Nuevo ID del nodo destino.
     **************************************************/
    void setIdDestino(int idDestino) {
        aIdDestino = idDestino;
    }

    /*****Nombre***************************************
     * setPeso
     *****Descripción**********************************
     * Establece el peso de la dependencia.
     *****Retorno**************************************
     * Ninguno.
     *****Entradas*************************************
     * - peso: Nuevo peso de la dependencia.
     **************************************************/
    void setPeso(int peso) {
        aPeso = peso;
    }

    /*****Nombre***************************************
     * getIdOrigen
     *****Descripción**********************************
     * Devuelve el ID del nodo origen de la dependencia.
     *****Retorno**************************************
     * ID del nodo origen.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    int getIdOrigen() {
        return aIdOrigen;
    }

    /*****Nombre***************************************
     * getIdDestino
     *****Descripción**********************************
     * Devuelve el ID del nodo destino de la dependencia.
     *****Retorno**************************************
     * ID del nodo destino.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    int getIdDestino() {
        return aIdDestino;
    }

    /*****Nombre***************************************
     * getPeso
     *****Descripción**********************************
     * Devuelve el peso de la dependencia.
     *****Retorno**************************************
     * Peso de la dependencia.
     *****Entradas*************************************
     * Ninguna.
     **************************************************/
    int getPeso() {
        return aPeso;
    }
};

#endif // DEPENDENCIA_HPP
